package com.sumit.playjava.model;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepo extends JpaRepository<User1, Integer>{

	User1 findByName(String userName);

}
